const dummy =
    [
        {
            "id": 1,
            "name": "Leanne Graham",
            "username": "bret",
            "email": "breat@gmail.com",
            "image": "https://source.unsplash.com/random",
            "followers": "100",
            "following": "100",
            "posts": [
                {
                    "id": 1,
                    "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
                    "image": "https://source.unsplash.com/random",
                    "time": "2020-12-12T12:12:12.000Z",
                    "likes": "100",
                    "comments": "100",
                }
            ]

        },
        {
            "id": 2,
            "name": "Ervin Howell",
            "username": "Antonette",
            "email": "ervin@gmail.com",
            "image": "https://source.unsplash.com/random",
            "followers": "100",
            "following": "100",
            "posts": [
                {
                    "id": 1,
                    "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
                    "image": "https://source.unsplash.com/random",
                    "time": "2020-12-12T12:12:12.000Z",
                    "likes": "100",
                    "comments": "100",
                }
            ]

        }
    ]
export default dummy;