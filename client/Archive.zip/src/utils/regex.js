// the Regex email validation was token from : https://emailregex.com/

export const EmailRegex =
	// eslint-disable-next-line no-useless-escape
	/^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
