import React from 'react'

const Followers = () => {
  return (
    <>
        <h1>Followers</h1>
    </>
  )
}

export default Followers