const data = {
    "data": [
        {
            userName: "dr_vk_singh",
            title: "Heathrow Airport",
            profile: "",
            image: "https://www.wwe.com/f/styles/gallery_img_l/public/all/2023/10/001_SD_10062023BR_20906--a0a2b1a6cdd9ada89f75560014cee3c8.jpg",
            posted: "10 minutes ago",
            likes: "100",
            comments: "10"

        },
        {
            userName: "viart_kohali",
            title: "We Did It 🙌",
            image: "https://www.hindustantimes.com/ht-img/img/2023/10/08/550x309/ANI-20231008262-0_1696786834260_1696786848700.jpg",
            posted: "18 minutes ago",
            likes: "100000",
            comments: "890"

        },
        {
            userName: "dr_vk_singh",
            title: "Heathrow Airport",
            image: "https://scontent.cdninstagram.com/v/t51.2885-15/386553277_856909589162387_8548399533328615511_n.webp?stp=dst-jpg_e35&efg=eyJ2ZW5jb2RlX3RhZyI6ImltYWdlX3VybGdlbi45MjB4OTIwLnNkciJ9&_nc_ht=scontent.cdninstagram.com&_nc_cat=111&_nc_ohc=rh-c89UjQ-kAX-H8dVH&edm=APs17CUBAAAA&ccb=7-5&ig_cache_key=MzIwODQyOTM1MDE3NjkzMjkyOQ%3D%3D.2-ccb7-5&oh=00_AfBnuPSNHJYehbcAC1tiX2HukHVxikDaXqWUY6UTUrrVAg&oe=652920A0&_nc_sid=10d13b.jpg",
            posted: "10 minutes ago",
            likes: "100",
            comments: "10"
        },


    ],

}
export default data;